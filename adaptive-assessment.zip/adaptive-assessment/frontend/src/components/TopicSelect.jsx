import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

const TOPICS = [
  { name: "Arrays", icon: "📦" },
  { name: "DBMS", icon: "🗄️" },
  { name: "OS", icon: "💻" },
  { name: "Networks", icon: "🌐" },
];

export default function TopicSelect({ student, onStart }) {
  const [selected, setSelected] = useState([]);
  const [questions, setQuestions] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const toggle = (t) => setSelected(s => s.includes(t) ? s.filter(x => x !== t) : [...s, t]);

  const start = async () => {
    if (!selected.length) return setError("Select at least one topic.");
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/session/start`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ student_id: student.student_id, topics: selected, total_questions: questions }),
      });
      const data = await res.json();
      onStart(data);
    } catch {
      setError("Failed to start session. Is the backend running?");
    }
    setLoading(false);
  };

  return (
    <div className="card">
      <h2>Hello, {student.name}! 👋</h2>
      <p className="subtitle">Choose your topics and question count. The exam adapts to your level as you go.</p>

      <div className="topics-grid">
        {TOPICS.map(t => (
          <div
            key={t.name}
            className={`topic-card ${selected.includes(t.name) ? "selected" : ""}`}
            onClick={() => toggle(t.name)}
          >
            <div className="topic-icon">{t.icon}</div>
            <div className="topic-name">{t.name}</div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: "20px" }}>
        <label style={{ color: "#94a3b8", fontSize: "0.85rem", display: "block", marginBottom: "8px" }}>
          Number of Questions: <strong style={{ color: "#a78bfa" }}>{questions}</strong>
        </label>
        <input
          type="range" min="5" max="20" value={questions}
          onChange={e => setQuestions(Number(e.target.value))}
          style={{ padding: 0, marginBottom: 0, accentColor: "#a78bfa" }}
        />
      </div>

      {error && <div className="error-box">{error}</div>}
      <button className="btn btn-primary" onClick={start} disabled={loading}>
        {loading ? "Starting..." : "Begin Adaptive Test →"}
      </button>
    </div>
  );
}
