import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export default function Register({ onRegister }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!name.trim() || !email.trim()) return setError("Please fill in all fields.");
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API}/api/students/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email }),
      });
      const data = await res.json();
      onRegister({ student_id: data.student_id, name, email });
    } catch {
      setError("Cannot connect to server. Make sure the backend is running.");
    }
    setLoading(false);
  };

  return (
    <div className="card">
      <h2>Welcome to AdaptIQ 🧠</h2>
      <p className="subtitle">An intelligent exam that adapts to your skill level in real-time.</p>

      <div style={{ display: "flex", gap: "16px", marginBottom: "8px", background: "rgba(167,139,250,0.08)", borderRadius: "12px", padding: "16px" }}>
        {["📊 Adjusts difficulty", "🎯 Finds your gaps", "📈 Skill report"].map(f => (
          <div key={f} style={{ flex: 1, textAlign: "center", fontSize: "0.8rem", color: "#94a3b8" }}>{f}</div>
        ))}
      </div>

      <div style={{ marginTop: "24px" }}>
        <input placeholder="Your full name" value={name} onChange={e => setName(e.target.value)} />
        <input placeholder="Email address" type="email" value={email} onChange={e => setEmail(e.target.value)} />
        {error && <div className="error-box">{error}</div>}
        <button className="btn btn-primary" onClick={submit} disabled={loading}>
          {loading ? "Registering..." : "Start Your Assessment →"}
        </button>
      </div>
    </div>
  );
}
