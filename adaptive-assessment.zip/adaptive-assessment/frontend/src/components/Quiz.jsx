import { useState, useEffect, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

const DIFF_CLASS = { 1: "d1", 2: "d2", 3: "d3", 4: "d4", 5: "d5" };

export default function Quiz({ session, student, onComplete }) {
  const [current, setCurrent] = useState(session.question);
  const [progress, setProgress] = useState(session.progress);
  const [selected, setSelected] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sessionId] = useState(session.session_id);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef(null);
  const startRef = useRef(Date.now());

  // Per-question timer
  useEffect(() => {
    startRef.current = Date.now();
    setElapsed(0);
    timerRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [current]);

  const submit = async () => {
    if (!selected || loading) return;
    clearInterval(timerRef.current);
    const responseTime = (Date.now() - startRef.current) / 1000;
    setLoading(true);

    const res = await fetch(`${API}/api/session/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: sessionId,
        question_id: current.question_id,
        selected_answer: selected,
        response_time: responseTime,
      }),
    });
    const data = await res.json();
    setFeedback({ text: data.feedback, correct: data.is_correct, answer: data.correct_answer });
    setLoading(false);

    if (data.status === "completed") {
      setTimeout(() => onComplete(data.profile), 1800);
    } else {
      setTimeout(() => {
        setCurrent(data.question);
        setProgress(data.progress);
        setSelected(null);
        setFeedback(null);
      }, 1800);
    }
  };

  const pct = Math.round(((progress.current - 1) / progress.total) * 100);

  return (
    <div className="card">
      <div className="quiz-meta">
        <span style={{ color: "#94a3b8", fontSize: "0.85rem" }}>
          Question <strong style={{ color: "#e2e8f0" }}>{progress.current}</strong> / {progress.total}
        </span>
        <span className={`difficulty-badge ${DIFF_CLASS[current.difficulty]}`}>
          {current.difficulty_label}
        </span>
        <span className="timer">⏱ {elapsed}s</span>
      </div>

      <div className="progress-bar-wrap">
        <div className="progress-bar-fill" style={{ width: `${pct}%` }} />
      </div>
      <div style={{ fontSize: "0.75rem", color: "#64748b", marginBottom: "20px", textAlign: "right" }}>
        Topic: <strong style={{ color: "#a78bfa" }}>{current.topic}</strong>
      </div>

      <p className="question-text">{current.question_text}</p>

      <div className="options">
        {current.options.map(opt => {
          let cls = "option-btn";
          if (feedback) {
            if (opt === feedback.answer) cls += " correct";
            else if (opt === selected && !feedback.correct) cls += " wrong";
          } else if (opt === selected) {
            cls += " selected";
          }
          return (
            <button
              key={opt}
              className={cls}
              disabled={!!feedback || loading}
              onClick={() => setSelected(opt)}
            >
              {opt}
            </button>
          );
        })}
      </div>

      {feedback && (
        <div className={`feedback ${feedback.correct ? "correct-fb" : "wrong-fb"}`}>
          {feedback.text}
        </div>
      )}

      {!feedback && (
        <button className="btn btn-primary" onClick={submit} disabled={!selected || loading}>
          {loading ? "Submitting..." : "Submit Answer"}
        </button>
      )}
    </div>
  );
}
