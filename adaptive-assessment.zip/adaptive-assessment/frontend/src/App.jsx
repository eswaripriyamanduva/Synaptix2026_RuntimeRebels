import { useState } from "react";
import Register from "./components/Register";
import TopicSelect from "./components/TopicSelect";
import Quiz from "./components/Quiz";
import Results from "./components/Results";
import "./App.css";

export default function App() {
  const [screen, setScreen] = useState("register"); // register | topics | quiz | results
  const [student, setStudent] = useState(null);
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);

  return (
    <div className="app">
      <header>
        <div className="logo">🧠 AdaptIQ</div>
        <div className="tagline">The exam that understands you</div>
      </header>

      <main>
        {screen === "register" && (
          <Register onRegister={(s) => { setStudent(s); setScreen("topics"); }} />
        )}
        {screen === "topics" && (
          <TopicSelect
            student={student}
            onStart={(sess) => { setSession(sess); setScreen("quiz"); }}
          />
        )}
        {screen === "quiz" && (
          <Quiz
            session={session}
            student={student}
            onComplete={(p) => { setProfile(p); setScreen("results"); }}
          />
        )}
        {screen === "results" && (
          <Results profile={profile} student={student} onRetake={() => setScreen("topics")} />
        )}
      </main>
    </div>
  );
}
