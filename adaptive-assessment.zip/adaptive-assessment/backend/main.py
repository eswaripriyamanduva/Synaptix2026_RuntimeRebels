from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import json, time, uuid
from datetime import datetime
from adaptive_engine import AdaptiveEngine
from database import Database

app = FastAPI(title="Adaptive Assessment Platform", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

db = Database()
engine = AdaptiveEngine()

# ─── Models ───────────────────────────────────────────────────────────────────

class StudentRegister(BaseModel):
    name: str
    email: str

class StartSession(BaseModel):
    student_id: str
    topics: List[str]
    total_questions: int = 10

class SubmitAnswer(BaseModel):
    session_id: str
    question_id: str
    selected_answer: str
    response_time: float  # seconds

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.post("/api/students/register")
def register_student(data: StudentRegister):
    student_id = str(uuid.uuid4())[:8]
    student = {
        "student_id": student_id,
        "name": data.name,
        "email": data.email,
        "created_at": datetime.now().isoformat()
    }
    db.save_student(student)
    return {"student_id": student_id, "message": "Registered successfully"}


@app.post("/api/session/start")
def start_session(data: StartSession):
    session_id = str(uuid.uuid4())[:12]
    session = {
        "session_id": session_id,
        "student_id": data.student_id,
        "topics": data.topics,
        "total_questions": data.total_questions,
        "current_question": 0,
        "current_difficulty": 2,  # Start at Easy
        "responses": [],
        "started_at": datetime.now().isoformat(),
        "status": "active"
    }
    db.save_session(session)
    question = engine.get_next_question(session)
    return {
        "session_id": session_id,
        "question": question,
        "progress": {"current": 1, "total": data.total_questions}
    }


@app.post("/api/session/submit")
def submit_answer(data: SubmitAnswer):
    session = db.get_session(data.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session["status"] != "active":
        raise HTTPException(status_code=400, detail="Session already completed")

    question = db.get_question(data.question_id)
    is_correct = question["correct_answer"].strip().lower() == data.selected_answer.strip().lower()

    response = {
        "question_id": data.question_id,
        "topic": question["topic"],
        "difficulty": question["difficulty"],
        "selected_answer": data.selected_answer,
        "is_correct": is_correct,
        "response_time": data.response_time
    }
    session["responses"].append(response)

    # Adaptive difficulty update
    new_difficulty = engine.update_difficulty(
        session["current_difficulty"], is_correct,
        data.response_time, session["responses"]
    )
    session["current_difficulty"] = new_difficulty
    session["current_question"] += 1

    # Check if test is complete
    if session["current_question"] >= session["total_questions"]:
        session["status"] = "completed"
        session["completed_at"] = datetime.now().isoformat()
        db.save_session(session)
        profile = engine.generate_competency_profile(session)
        db.save_profile(session["student_id"], profile)
        return {
            "status": "completed",
            "is_correct": is_correct,
            "correct_answer": question["correct_answer"],
            "feedback": "✅ Correct!" if is_correct else f"❌ Wrong! Correct: {question['correct_answer']}",
            "profile": profile
        }

    db.save_session(session)
    next_question = engine.get_next_question(session)
    return {
        "status": "continue",
        "is_correct": is_correct,
        "correct_answer": question["correct_answer"],
        "feedback": "✅ Correct!" if is_correct else f"❌ Wrong! Correct: {question['correct_answer']}",
        "question": next_question,
        "progress": {
            "current": session["current_question"] + 1,
            "total": session["total_questions"]
        },
        "current_difficulty": new_difficulty
    }


@app.get("/api/profile/{student_id}")
def get_profile(student_id: str):
    profile = db.get_profile(student_id)
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    return profile


@app.get("/api/questions/topics")
def get_topics():
    return {"topics": db.get_all_topics()}


@app.get("/api/health")
def health():
    return {"status": "ok", "timestamp": datetime.now().isoformat()}
