export default function Results({ profile, student, onRetake }) {
  if (!profile) return <div className="loading"><div className="spinner" /><p>Generating your profile...</p></div>;

  const getColor = (acc) => acc >= 85 ? "#10b981" : acc >= 70 ? "#3b82f6" : acc >= 50 ? "#f59e0b" : "#ef4444";

  const downloadReport = () => {
    const lines = [
      `AdaptIQ Competency Report`,
      `Student: ${student.name}  |  Email: ${student.email}`,
      `Date: ${new Date().toLocaleString()}`,
      `Overall Accuracy: ${profile.overall_accuracy}%  |  ${profile.overall_mastery}`,
      ``,
      `Topic Breakdown:`,
      ...profile.topics.map(t =>
        `  ${t.topic}: ${t.accuracy}% | ${t.mastery_level} | ${t.correct_answers}/${t.questions_attempted} correct | Avg time: ${t.avg_response_time}s | Max difficulty: ${t.max_difficulty_reached}`
      ),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `AdaptIQ_Report_${student.name.replace(/\s/g, "_")}.txt`;
    a.click();
  };

  return (
    <div className="card">
      <h2>Your Competency Profile 📊</h2>
      <p className="subtitle">Based on your adaptive assessment</p>

      <div className="overall-score">
        <div className="score-number">{profile.overall_accuracy}%</div>
        <div className="score-label">Overall Accuracy · {profile.total_correct}/{profile.total_questions} correct</div>
        <div className="mastery-badge">{profile.overall_mastery}</div>
      </div>

      <h3 style={{ color: "#94a3b8", fontSize: "0.85rem", textTransform: "uppercase", letterSpacing: "1px", marginBottom: "14px" }}>
        Per-Topic Breakdown
      </h3>

      {profile.topics.map(t => (
        <div key={t.topic} className="topic-row">
          <div className="topic-header">
            <span className="topic-title">{t.topic}</span>
            <span className="topic-accuracy" style={{ color: getColor(t.accuracy) }}>{t.accuracy}%</span>
          </div>
          <div className="topic-progress">
            <div
              className="topic-progress-fill"
              style={{ width: `${t.accuracy}%`, background: `linear-gradient(90deg, ${getColor(t.accuracy)}, ${getColor(t.accuracy)}aa)` }}
            />
          </div>
          <div className="topic-meta">
            <span>{t.mastery_level}</span>
            <span>✅ {t.correct_answers}/{t.questions_attempted}</span>
            <span>⏱ {t.avg_response_time}s avg</span>
            <span>🔝 {t.max_difficulty_reached}</span>
          </div>
        </div>
      ))}

      {/* Legend */}
      <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginTop: "20px", padding: "12px", background: "rgba(255,255,255,0.04)", borderRadius: "10px" }}>
        {[["85%+", "Expert 🏆", "#10b981"], ["70–84%", "Advanced ⭐", "#3b82f6"], ["50–69%", "Intermediate 📘", "#f59e0b"], ["<50%", "Beginner 🌱", "#ef4444"]].map(([range, label, color]) => (
          <div key={range} style={{ fontSize: "0.75rem", color: "#64748b" }}>
            <span style={{ color, fontWeight: 700 }}>{range}</span> {label}
          </div>
        ))}
      </div>

      <div className="results-actions">
        <button className="btn btn-secondary" onClick={downloadReport}>⬇ Download Report</button>
        <button className="btn btn-primary" onClick={onRetake}>🔁 Retake Test</button>
      </div>
    </div>
  );
}
