"""
Adaptive Engine - Core Intelligence of the Platform
Uses a hybrid approach:
  1. Rule-based difficulty adjustment
  2. Moving average accuracy tracking
  3. Response time analysis (detect guessing)
  4. Elo-inspired scoring
"""

import random
from typing import List, Dict
from database import Database

db = Database()


class AdaptiveEngine:

    DIFFICULTY_LABELS = {1: "Very Easy", 2: "Easy", 3: "Medium", 4: "Hard", 5: "Very Hard"}
    MASTERY_LEVELS = [
        (85, "Expert 🏆"),
        (70, "Advanced ⭐"),
        (50, "Intermediate 📘"),
        (0,  "Beginner 🌱"),
    ]

    def get_next_question(self, session: dict) -> dict:
        """Pick next question matching current difficulty and topics."""
        difficulty = session["current_difficulty"]
        topics = session["topics"]
        answered_ids = [r["question_id"] for r in session["responses"]]

        # Try exact difficulty first, then ±1
        for diff in [difficulty, difficulty - 1, difficulty + 1, difficulty - 2, difficulty + 2]:
            diff = max(1, min(5, diff))
            questions = db.get_questions_by_filter(topics, diff, exclude_ids=answered_ids)
            if questions:
                q = random.choice(questions)
                # Shuffle options
                options = q["options"][:]
                random.shuffle(options)
                return {
                    "question_id": q["question_id"],
                    "topic": q["topic"],
                    "difficulty": diff,
                    "difficulty_label": self.DIFFICULTY_LABELS[diff],
                    "question_text": q["question_text"],
                    "options": options,
                    "marks": q["marks"]
                }
        raise Exception("No more questions available")

    def update_difficulty(
        self,
        current: int,
        is_correct: bool,
        response_time: float,
        responses: List[Dict]
    ) -> int:
        """
        Adaptive difficulty update using:
        - Correctness (+1 / -1)
        - Moving accuracy of last 3 answers
        - Response time (fast + wrong = possible guessing → extra -1)
        """
        new_diff = current

        # Base rule
        if is_correct:
            new_diff += 1
        else:
            new_diff -= 1

        # Moving accuracy bonus/penalty
        if len(responses) >= 3:
            last3 = responses[-3:]
            accuracy = sum(1 for r in last3 if r["is_correct"]) / 3
            if accuracy == 1.0:   # 3/3 correct → push harder
                new_diff += 1
            elif accuracy == 0.0: # 3/3 wrong → ease off
                new_diff -= 1

        # Guess detection: answered too fast AND wrong (< 4 seconds)
        if not is_correct and response_time < 4.0:
            new_diff -= 1  # penalize guessing

        return max(1, min(5, new_diff))

    def generate_competency_profile(self, session: dict) -> dict:
        """Generate per-topic competency profile after test completion."""
        responses = session["responses"]
        topic_stats: Dict[str, Dict] = {}

        for r in responses:
            t = r["topic"]
            if t not in topic_stats:
                topic_stats[t] = {
                    "correct": 0, "total": 0,
                    "max_difficulty": 0,
                    "total_time": 0.0
                }
            topic_stats[t]["total"] += 1
            topic_stats[t]["total_time"] += r.get("response_time", 0)
            if r["is_correct"]:
                topic_stats[t]["correct"] += 1
            if r["difficulty"] > topic_stats[t]["max_difficulty"]:
                topic_stats[t]["max_difficulty"] = r["difficulty"]

        profile = []
        for topic, stats in topic_stats.items():
            accuracy = round((stats["correct"] / stats["total"]) * 100, 1)
            mastery = self._get_mastery(accuracy)
            avg_time = round(stats["total_time"] / stats["total"], 1)
            profile.append({
                "topic": topic,
                "accuracy": accuracy,
                "mastery_level": mastery,
                "questions_attempted": stats["total"],
                "correct_answers": stats["correct"],
                "max_difficulty_reached": self.DIFFICULTY_LABELS[stats["max_difficulty"]],
                "avg_response_time": avg_time
            })

        total_correct = sum(s["correct"] for s in topic_stats.values())
        total_q = len(responses)
        overall = round((total_correct / total_q) * 100, 1) if total_q else 0

        return {
            "student_id": session["student_id"],
            "session_id": session["session_id"],
            "topics": profile,
            "overall_accuracy": overall,
            "overall_mastery": self._get_mastery(overall),
            "total_questions": total_q,
            "total_correct": total_correct,
            "generated_at": __import__("datetime").datetime.now().isoformat()
        }

    def _get_mastery(self, accuracy: float) -> str:
        for threshold, label in self.MASTERY_LEVELS:
            if accuracy >= threshold:
                return label
        return "Beginner 🌱"
