# 🧠 AdaptIQ — Adaptive Online Assessment Platform

> "Our platform does not just test students, it understands them."

---

## 📁 Project Structure

```
adaptive-assessment/
├── backend/
│   ├── main.py              ← FastAPI routes
│   ├── adaptive_engine.py   ← Core adaptive algorithm
│   ├── database.py          ← Data layer (JSON → swap with PostgreSQL)
│   ├── seed_questions.py    ← Seed initial question bank
│   ├── requirements.txt
│   └── data/                ← Auto-created on first run
│       ├── questions.json
│       ├── students.json
│       ├── sessions.json
│       └── profiles.json
│
└── frontend/
    ├── src/
    │   ├── App.jsx           ← Root component + routing
    │   ├── App.css           ← All styles
    │   ├── main.jsx          ← Entry point
    │   └── components/
    │       ├── Register.jsx      ← Student registration
    │       ├── TopicSelect.jsx   ← Topic & question count picker
    │       ├── Quiz.jsx          ← Live adaptive quiz
    │       └── Results.jsx       ← Competency profile + download
    ├── index.html
    ├── vite.config.js
    └── package.json
```

---

## 🚀 Step-by-Step Setup Guide

### PREREQUISITES (Install these first)
- Python 3.10+ → https://python.org
- Node.js 18+ → https://nodejs.org
- A terminal (CMD, PowerShell, or Terminal on Mac/Linux)

---

### STEP 1 — Set Up the Backend

Open a terminal and navigate to the `backend` folder:

```bash
cd adaptive-assessment/backend
```

Create a Python virtual environment:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Seed the question bank (run ONCE):
```bash
python seed_questions.py
```
You should see: ✅ Seeded 32 questions across topics: Arrays, DBMS, OS, Networks

Start the backend server:
```bash
uvicorn main:app --reload --port 8000
```

✅ Backend is running at: http://localhost:8000
📖 API docs available at: http://localhost:8000/docs

---

### STEP 2 — Set Up the Frontend

Open a NEW terminal (keep backend running), navigate to `frontend`:

```bash
cd adaptive-assessment/frontend
```

Copy the environment file:
```bash
# Windows
copy .env.example .env

# Mac/Linux
cp .env.example .env
```

Install Node packages:
```bash
npm install
```

Start the frontend dev server:
```bash
npm run dev
```

✅ Frontend is running at: http://localhost:3000

---

### STEP 3 — Use the App

1. Open http://localhost:3000 in your browser
2. Register with your name and email
3. Select topics (Arrays, DBMS, OS, Networks)
4. Choose number of questions (5–20)
5. Take the adaptive test — watch difficulty change!
6. View your Competency Profile at the end
7. Download your report as a .txt file

---

## 🧠 How the Adaptive Algorithm Works

```
Student answers question
        ↓
Is answer correct?
   YES → difficulty + 1
   NO  → difficulty - 1
        ↓
Check last 3 answers
   3/3 correct → difficulty + 1 (push harder)
   0/3 correct → difficulty - 1 (ease off)
        ↓
Check response time
   Wrong + < 4 seconds → difficulty - 1 (penalize guessing)
        ↓
Clamp to range [1, 5]
        ↓
Pick next question at new difficulty
```

Mastery Classification:
| Accuracy | Level |
|----------|-------|
| 85%+ | Expert 🏆 |
| 70–84% | Advanced ⭐ |
| 50–69% | Intermediate 📘 |
| <50% | Beginner 🌱 |

---

## 🗄 Database Migration (for Production)

The `database.py` file uses JSON for simplicity. To use PostgreSQL:

1. Install: `pip install psycopg2-binary sqlalchemy`
2. Replace methods in `database.py` with SQLAlchemy queries
3. Create tables matching the structure in `database.py`

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/students/register | Register student |
| POST | /api/session/start | Start adaptive session |
| POST | /api/session/submit | Submit answer, get next question |
| GET | /api/profile/{student_id} | Get competency profile |
| GET | /api/questions/topics | List available topics |
| GET | /api/health | Health check |

---

## ☁ Deployment

### Option A: Railway (Easiest)
1. Push to GitHub
2. Go to https://railway.app → New Project → Deploy from GitHub
3. Set backend root to `/backend`, start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Add frontend as separate service, build command: `npm run build`, publish: `dist`

### Option B: Render
1. Backend: New Web Service → Python → `uvicorn main:app --host 0.0.0.0 --port $PORT`
2. Frontend: New Static Site → `npm run build` → publish `dist`

### Option C: Vercel + Render
- Frontend → Vercel (automatic from GitHub)
- Backend → Render.com free tier

---

## 🏆 Extra Features to Add (Bonus Points)
- [ ] AI-generated questions using Claude/GPT API
- [ ] Leaderboard (add `GET /api/leaderboard` endpoint)
- [ ] PDF report download (use `reportlab` in Python)
- [ ] Topic recommendation after test
- [ ] Timer that auto-submits at 0
- [ ] Tab-switch detection (`document.addEventListener('visibilitychange', ...)`)

---

## 🎤 Presentation Tips
1. Start with: "Traditional exams give everyone the same paper. That's unfair."
2. Show the live demo — pick a topic, answer wrong intentionally, show difficulty drop
3. Show the competency report at the end
4. Explain the algorithm in 30 seconds using the flow diagram above
5. End with: "Our platform does not just test students, it understands them."
