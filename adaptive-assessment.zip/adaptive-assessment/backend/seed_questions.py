"""
Run this script once to populate the questions database.
  python seed_questions.py
"""

import json, os

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

questions = {
    # ── Arrays ────────────────────────────────────────────────────────────────
    "q001": {"question_id":"q001","topic":"Arrays","difficulty":1,"question_text":"What is the index of the first element in an array?","options":["0","1","-1","Depends on language"],"correct_answer":"0","marks":1},
    "q002": {"question_id":"q002","topic":"Arrays","difficulty":1,"question_text":"Which of these creates an array in Python?","options":["arr = []","arr = {}","arr = ()","arr = <>"],"correct_answer":"arr = []","marks":1},
    "q003": {"question_id":"q003","topic":"Arrays","difficulty":2,"question_text":"What is the time complexity of accessing an element by index in an array?","options":["O(1)","O(n)","O(log n)","O(n²)"],"correct_answer":"O(1)","marks":2},
    "q004": {"question_id":"q004","topic":"Arrays","difficulty":2,"question_text":"What is the worst-case time complexity of linear search in an array?","options":["O(n)","O(1)","O(log n)","O(n log n)"],"correct_answer":"O(n)","marks":2},
    "q005": {"question_id":"q005","topic":"Arrays","difficulty":3,"question_text":"Given array [3,1,4,1,5,9], what is the output after sorting in ascending order?","options":["[1,1,3,4,5,9]","[9,5,4,3,1,1]","[3,1,4,1,5,9]","[1,3,4,1,5,9]"],"correct_answer":"[1,1,3,4,5,9]","marks":3},
    "q006": {"question_id":"q006","topic":"Arrays","difficulty":3,"question_text":"What is the space complexity of merge sort?","options":["O(n)","O(1)","O(log n)","O(n²)"],"correct_answer":"O(n)","marks":3},
    "q007": {"question_id":"q007","topic":"Arrays","difficulty":4,"question_text":"Which algorithm finds the k-th largest element in O(n) average time?","options":["QuickSelect","Merge Sort","Bubble Sort","Binary Search"],"correct_answer":"QuickSelect","marks":4},
    "q008": {"question_id":"q008","topic":"Arrays","difficulty":5,"question_text":"What is the time complexity of the best known algorithm for finding the median of two sorted arrays?","options":["O(log(m+n))","O(m+n)","O(n)","O(log n)"],"correct_answer":"O(log(m+n))","marks":5},

    # ── DBMS ──────────────────────────────────────────────────────────────────
    "q101": {"question_id":"q101","topic":"DBMS","difficulty":1,"question_text":"What does SQL stand for?","options":["Structured Query Language","Simple Query Language","Standard Query Logic","Structured Question Language"],"correct_answer":"Structured Query Language","marks":1},
    "q102": {"question_id":"q102","topic":"DBMS","difficulty":1,"question_text":"Which SQL command retrieves data from a table?","options":["SELECT","INSERT","UPDATE","DELETE"],"correct_answer":"SELECT","marks":1},
    "q103": {"question_id":"q103","topic":"DBMS","difficulty":2,"question_text":"What is a primary key?","options":["Uniquely identifies each row","Can have NULL values","Can be duplicated","Foreign reference to another table"],"correct_answer":"Uniquely identifies each row","marks":2},
    "q104": {"question_id":"q104","topic":"DBMS","difficulty":2,"question_text":"Which normal form eliminates partial dependencies?","options":["2NF","1NF","3NF","BCNF"],"correct_answer":"2NF","marks":2},
    "q105": {"question_id":"q105","topic":"DBMS","difficulty":3,"question_text":"What does ACID stand for in database transactions?","options":["Atomicity, Consistency, Isolation, Durability","Accuracy, Consistency, Integrity, Durability","Atomicity, Concurrency, Isolation, Dependency","Accuracy, Concurrency, Integration, Durability"],"correct_answer":"Atomicity, Consistency, Isolation, Durability","marks":3},
    "q106": {"question_id":"q106","topic":"DBMS","difficulty":3,"question_text":"Which join returns all rows from both tables, with NULLs where no match?","options":["FULL OUTER JOIN","INNER JOIN","LEFT JOIN","CROSS JOIN"],"correct_answer":"FULL OUTER JOIN","marks":3},
    "q107": {"question_id":"q107","topic":"DBMS","difficulty":4,"question_text":"What is a deadlock in DBMS?","options":["Two transactions waiting for each other indefinitely","A slow query","A missing index","A corrupted record"],"correct_answer":"Two transactions waiting for each other indefinitely","marks":4},
    "q108": {"question_id":"q108","topic":"DBMS","difficulty":5,"question_text":"In B+ trees, all data is stored at which level?","options":["Leaf nodes","Root node","Internal nodes","All levels equally"],"correct_answer":"Leaf nodes","marks":5},

    # ── OS ────────────────────────────────────────────────────────────────────
    "q201": {"question_id":"q201","topic":"OS","difficulty":1,"question_text":"What is the full form of OS?","options":["Operating System","Operational Software","Open Source","Optical Storage"],"correct_answer":"Operating System","marks":1},
    "q202": {"question_id":"q202","topic":"OS","difficulty":1,"question_text":"Which part of OS manages CPU scheduling?","options":["Kernel","Shell","GUI","File System"],"correct_answer":"Kernel","marks":1},
    "q203": {"question_id":"q203","topic":"OS","difficulty":2,"question_text":"What is a process?","options":["A program in execution","A file on disk","A hardware component","A network connection"],"correct_answer":"A program in execution","marks":2},
    "q204": {"question_id":"q204","topic":"OS","difficulty":2,"question_text":"Which scheduling algorithm has minimum average waiting time?","options":["SJF","FCFS","Round Robin","Priority"],"correct_answer":"SJF","marks":2},
    "q205": {"question_id":"q205","topic":"OS","difficulty":3,"question_text":"What is thrashing in OS?","options":["Excessive paging causing low CPU utilization","High CPU usage","Memory overflow","Disk corruption"],"correct_answer":"Excessive paging causing low CPU utilization","marks":3},
    "q206": {"question_id":"q206","topic":"OS","difficulty":3,"question_text":"Which page replacement algorithm suffers from Belady's anomaly?","options":["FIFO","LRU","Optimal","Clock"],"correct_answer":"FIFO","marks":3},
    "q207": {"question_id":"q207","topic":"OS","difficulty":4,"question_text":"What is a semaphore used for?","options":["Process synchronization","Memory allocation","CPU scheduling","Disk management"],"correct_answer":"Process synchronization","marks":4},
    "q208": {"question_id":"q208","topic":"OS","difficulty":5,"question_text":"In the Banker's Algorithm, what does the 'Need' matrix represent?","options":["Maximum - Allocation","Maximum + Allocation","Available - Allocation","Allocation - Available"],"correct_answer":"Maximum - Allocation","marks":5},

    # ── Networks ──────────────────────────────────────────────────────────────
    "q301": {"question_id":"q301","topic":"Networks","difficulty":1,"question_text":"What does HTTP stand for?","options":["HyperText Transfer Protocol","High Transfer Text Protocol","Hyper Transfer Text Process","HyperText Technical Protocol"],"correct_answer":"HyperText Transfer Protocol","marks":1},
    "q302": {"question_id":"q302","topic":"Networks","difficulty":2,"question_text":"Which layer of OSI model handles routing?","options":["Network Layer","Transport Layer","Data Link Layer","Application Layer"],"correct_answer":"Network Layer","marks":2},
    "q303": {"question_id":"q303","topic":"Networks","difficulty":3,"question_text":"What is the purpose of ARP?","options":["Map IP address to MAC address","Map MAC to IP","Assign IP addresses","Route packets"],"correct_answer":"Map IP address to MAC address","marks":3},
    "q304": {"question_id":"q304","topic":"Networks","difficulty":4,"question_text":"What is the time complexity of Dijkstra's algorithm with a min-heap?","options":["O((V+E) log V)","O(V²)","O(E log E)","O(VE)"],"correct_answer":"O((V+E) log V)","marks":4},
    "q305": {"question_id":"q305","topic":"Networks","difficulty":5,"question_text":"What is the sliding window protocol's main advantage?","options":["Allows multiple frames in transit simultaneously","Reduces latency","Increases bandwidth","Eliminates errors"],"correct_answer":"Allows multiple frames in transit simultaneously","marks":5},
}

with open(os.path.join(DATA_DIR, "questions.json"), "w") as f:
    json.dump(questions, f, indent=2)

print(f"✅ Seeded {len(questions)} questions across topics: Arrays, DBMS, OS, Networks")
