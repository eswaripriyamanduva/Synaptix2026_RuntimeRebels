"""
Database Layer
Uses JSON files for simplicity — easy to swap with PostgreSQL or MongoDB.
See comments marked with # POSTGRES and # MONGO for migration hints.
"""

import json
import os
from typing import List, Optional, Dict

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)


def _load(filename: str) -> dict:
    path = os.path.join(DATA_DIR, filename)
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)


def _save(filename: str, data: dict):
    path = os.path.join(DATA_DIR, filename)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


class Database:

    # ── Students ──────────────────────────────────────────────────────────────
    def save_student(self, student: dict):
        db = _load("students.json")
        db[student["student_id"]] = student
        _save("students.json", db)

    def get_student(self, student_id: str) -> Optional[dict]:
        return _load("students.json").get(student_id)

    # ── Sessions ──────────────────────────────────────────────────────────────
    def save_session(self, session: dict):
        db = _load("sessions.json")
        db[session["session_id"]] = session
        _save("sessions.json", db)

    def get_session(self, session_id: str) -> Optional[dict]:
        return _load("sessions.json").get(session_id)

    # ── Questions ─────────────────────────────────────────────────────────────
    def get_questions_by_filter(
        self,
        topics: List[str],
        difficulty: int,
        exclude_ids: List[str]
    ) -> List[dict]:
        db = _load("questions.json")
        return [
            q for q in db.values()
            if q["topic"] in topics
            and q["difficulty"] == difficulty
            and q["question_id"] not in exclude_ids
        ]

    def get_question(self, question_id: str) -> Optional[dict]:
        return _load("questions.json").get(question_id)

    def get_all_topics(self) -> List[str]:
        db = _load("questions.json")
        return list(set(q["topic"] for q in db.values()))

    # ── Profiles ──────────────────────────────────────────────────────────────
    def save_profile(self, student_id: str, profile: dict):
        db = _load("profiles.json")
        db[student_id] = profile
        _save("profiles.json", db)

    def get_profile(self, student_id: str) -> Optional[dict]:
        return _load("profiles.json").get(student_id)
